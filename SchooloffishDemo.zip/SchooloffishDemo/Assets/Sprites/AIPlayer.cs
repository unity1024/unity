﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(PolyNavAgent))]
public class AIPlayer : MonoBehaviour {


    //巡逻点————用于暂时找不到怪物和没有怪物时 开始巡逻
    public List<Vector2> patrol = new List<Vector2>();


    public GameObject player;//player父对象
    public int playCount;

    public class player_node//蜜蜂
    {
        public Transform transform;//蜜蜂对象
        public bool mainobj;//判断是否是蜜蜂主对象 主要用于多分队会合  重新设计——这里应该是蜜蜂对象是否空闲
        public Vector3 endposition;//目标位置--可以是敌人，也可以是主对象

        public float hurt;//攻击值
        //public PolyNavAgent _agent;//无效
    }


    public List<player_node> play_lis = new List<player_node>();//蜜蜂List对象

    public GameObject Enemyobj;//敌人的父对象

    public class enemyobj_node
    {
        public Transform enemyobj;//敌人对象
        public animationstate state;//状态值 用于动画操作
        public float lifevlue;//生命值
        public int leftorright;//朝左还是朝右
    }



    public List<enemyobj_node> enemyobj_lis = new List<enemyobj_node>();//敌人的List对象

    //蜜蜂搜寻半径
    public float dis = 20f;

    //敌人的动画
    public enum animationstate
    {
        sleep,
        run,
        dite
    }


    public RuntimeAnimatorController Aidm;
    public RuntimeAnimatorController Aidz;
    public RuntimeAnimatorController Aidd;
    public RuntimeAnimatorController Aidmr;
    public RuntimeAnimatorController Aidzr;
    public RuntimeAnimatorController Aiddr;

    public RuntimeAnimatorController blood;
    public Sprite image;

    //蜜蜂追踪对象目标
    public enum playOren
    {
        play,
        en
    }

   
    public struct end_node
    {
        public Transform transformend;//当前目标对象
        public playOren playOren;//判断当前目标对象是蜜蜂还是怪物
        public int id;
    }
    private List<end_node> end_Nodes = new List<end_node>();//存储当前所有目标对象



    public int Aiplayen = 0;


    // Use this for initialization
    void Start () {

        if (playCount > 0)
        {
           for(int i = 0; i < playCount; ++i)//创建蜜蜂
            {
                GameObject game = Instantiate((GameObject)Resources.Load("Prefabs/playnode"));
                game.transform.name = "playnode"+i;
                
                game.transform.parent = player.transform;
                game.transform.position = new Vector3(Screen.width/2-100f+ UnityEngine.Random.value*50f-25f,Screen.height/2+100f+ UnityEngine.Random.value*50f-25f , -1.62f);

                player_node player_Node = new player_node();
                player_Node.transform = game.transform;
                player_Node.mainobj = false;
                player_Node.hurt = 3f;
                player_Node.endposition = new Vector3(-10000,-10000,-10000);
                //player_Node._agent = game.transform.GetComponent<PolyNavAgent>();
                play_lis.Add(player_Node);
            }
        }

        //获取敌人对象
        Enemyobj = GameObject.Find("Enemyobj");

        foreach(Transform t in Enemyobj.transform.GetComponentsInChildren<Transform>())
        {
            if (t.name.Equals("Enemyobj"))
            {

            }
            else
            {
                enemyobj_node enemyobj_Node = new enemyobj_node();//保存到怪物集合里  里面有怪物基础属性
                enemyobj_Node.enemyobj = t;
                enemyobj_Node.state = animationstate.sleep;
                enemyobj_Node.lifevlue = 50;
                enemyobj_lis.Add(enemyobj_Node);
            }
            
        }

        for(int i = 0; i < patrol.Count; ++i)
        { 
            play_lis[0].transform.GetComponent<Play2D>().vector2s.Add(patrol[i]);
        }

        InvokeRepeating("movePlayAi", 3f, 2f);


        InvokeRepeating("Colliene_play", 5f, 2f);

        InvokeRepeating("enemyAi", 5f, 10f);

    }
	
	// Update is called once per frame
	void Update () {
       
	}

    //player的AI追踪和分配功能
    void movePlayAi()
    {
        //for (int i=0;i<end_Nodes.Count;++i)
        //{
        //    Debug.Log("i:"+i+","+end_Nodes[i].transformend.name);
        //}

        end_Nodes.Clear();
        Debug.Log("movePlayAi");
        for (int i = 0; i < play_lis.Count; ++i)
        {
            play_lis[i].transform.GetComponent<PolyNavAgent>().maxSpeed = 10f;
        }



        foreach(player_node player_ in play_lis)//获取怪物目标对象  可能会重复 稍后处理重复对象
        {
           foreach(enemyobj_node enemyobj_ in enemyobj_lis)
            {
                if (Vector2.Distance(new Vector2(player_.transform.position.x,player_.transform.position.y),
                    new Vector2(enemyobj_.enemyobj.position.x,enemyobj_.enemyobj.position.y))<=this.dis)
                {
                    end_node end_;
                    end_.transformend = enemyobj_.enemyobj;
                    end_.playOren = playOren.en;
                    end_.id = end_Nodes.Count + 1;
                    end_Nodes.Add(end_);
                }
            }
        }

        //先去除重复对象 --可能有多个怪物或者是蜜蜂对象
        for(int i = 0; i < end_Nodes.Count; ++i)
        {
            for(int j = i + 1; j < end_Nodes.Count; ++j)
            {
                if (end_Nodes[i].transformend.name.Equals(end_Nodes[j].transformend.name))
                {
                    List<end_node> _Nodes = new List<end_node>();
                    for(int k = 0; k < end_Nodes.Count; ++k)
                    {
                        if (k != j)
                        {
                            _Nodes.Add(end_Nodes[k]);
                        }
                    }
                    end_Nodes.Clear();

                    for(int k = 0; k < _Nodes.Count; ++k)
                    {
                        end_Nodes.Add(_Nodes[k]);
                    }
                    j--;
                }
            }
        }

        if (end_Nodes.Count > 0)
        {

            Aiplayen = 1;
            Debug.Log("追踪怪物个数:" + end_Nodes.Count);
            if (end_Nodes.Count == 4)
            {
                play_lis[0].transform.GetComponent<Play2D>().WPoints = end_Nodes[0].transformend.position;
                play_lis[1].transform.GetComponent<Play2D>().WPoints = end_Nodes[0].transformend.position;
                play_lis[2].transform.GetComponent<Play2D>().WPoints = end_Nodes[1].transformend.position;
                play_lis[3].transform.GetComponent<Play2D>().WPoints = end_Nodes[1].transformend.position;
                play_lis[4].transform.GetComponent<Play2D>().WPoints = end_Nodes[2].transformend.position;
                play_lis[5].transform.GetComponent<Play2D>().WPoints = end_Nodes[3].transformend.position;

                play_lis[0].transform.GetComponent<Play2D>().MoveRandom();
                play_lis[1].transform.GetComponent<Play2D>().MoveRandom();
                play_lis[2].transform.GetComponent<Play2D>().MoveRandom();
                play_lis[3].transform.GetComponent<Play2D>().MoveRandom();
                play_lis[4].transform.GetComponent<Play2D>().MoveRandom();
                play_lis[5].transform.GetComponent<Play2D>().MoveRandom();
            }
            else
            {
                for(int i = 0; i < end_Nodes.Count; ++i)
                {
                    for(int j=i*(play_lis.Count/end_Nodes.Count);j<(i+1)*(play_lis.Count / end_Nodes.Count); ++j)
                    {
                        //play_lis[j]._agent.SetDestination(end_Nodes[i].transformend.position);//追踪怪物
                        play_lis[j].transform.GetComponent<Play2D>().WPoints = end_Nodes[i].transformend.position;
                        play_lis[j].transform.GetComponent<Play2D>().MoveRandom();
                    }
                }
            }
        }

        if (end_Nodes.Count <= 0)
        {
             for(int i=0;i<play_lis.Count;++i)
            {
                
                if (i>0)
                {
                    play_lis[i].transform.GetComponent<PolyNavAgent>().maxSpeed = 30f;
                    //play_lis[i]._agent.SetDestination(play_lis[0].transform.position);
                    play_lis[i].transform.GetComponent<Play2D>().WPoints = play_lis[0].transform.position;
                    play_lis[i].transform.GetComponent<Play2D>().MoveRandom();
                }
                else if(Aiplayen!=-1)
                {
                    //play_lis[i]._agent.SetDestination(patrol[(int)(Random.value*patrol.Count)]);//巡逻
                    //play_lis[i].transform.GetComponent<Play2D>().WPoints = patrol[(int)(Random.value * patrol.Count)];
                    //play_lis[i].transform.GetComponent<Play2D>().MoveRandom();


                    Aiplayen = 2;
                }
            }
        }


        if (Aiplayen==2)
        {
            play_lis[0].transform.GetComponent<Play2D>().WPoints = patrol[(int)(UnityEngine.Random.value * patrol.Count)];
            play_lis[0].transform.GetComponent<Play2D>().MoveRandom();
            play_lis[0].transform.GetComponent<Play2D>().Onrun();
            Aiplayen = -1;
            
        }else if (Aiplayen == 1)
        {
             play_lis[0].transform.GetComponent<Play2D>().Onstop();
            Aiplayen = 0;
        }


      
    }

    //碰撞检测
    void Colliene_play()
    {

        foreach (player_node player_ in play_lis)
        {
            foreach (enemyobj_node enemyobj_ in enemyobj_lis)
            {
                if (Vector2.Distance(player_.transform.position, enemyobj_.enemyobj.position) <= 20f)
                {
                    enemyobj_.lifevlue -= player_.hurt;

                    if (enemyobj_.lifevlue <= 0)
                    {
                        enemyobj_.state = animationstate.dite;
                    }
                }
            }
        }
    }

    //敌人的Ai
    void enemyAi()
    {
        
        //AI寻路

        foreach (enemyobj_node enemyobj_ in enemyobj_lis)
        {
            if (enemyobj_!=null&&enemyobj_.state != animationstate.dite)
            {
                foreach (player_node player_ in play_lis)
                {
                    if (Vector2.Distance(player_.transform.position, enemyobj_.enemyobj.position) <= 50f)
                    {
                        //寻路
                        enemyobj_.leftorright = (player_.transform.position.x > enemyobj_.enemyobj.position.x) ? 1 : 0;//1：蜜蜂在怪物右边 0默认左边

                        if (enemyobj_.leftorright == 0)
                        {
                            enemyobj_.enemyobj.GetComponent<Play2D>().WPoints = patrol[(int)(UnityEngine.Random.value * 3)];
                        }
                        else
                        {
                            enemyobj_.enemyobj.GetComponent<Play2D>().WPoints = patrol[(int)(UnityEngine.Random.value * 2+3)];
                        }
                        
                        enemyobj_.enemyobj.GetComponent<Play2D>().MoveRandom();
                        enemyobj_.state = animationstate.run;
                        break;
                    }
                }
            }

        }
        


        //AI播放当前动画
        foreach(enemyobj_node enemyobj_ in enemyobj_lis)
        {
            if (enemyobj_!=null&&enemyobj_.state == animationstate.run)
            {
                //播放运行动画
                if(enemyobj_ != null)
                {
                    if (enemyobj_.leftorright == 0)
                    {
                        enemyobj_.enemyobj.GetComponent<Animator>().runtimeAnimatorController = this.Aidm;
                    }
                    else
                    {
                        enemyobj_.enemyobj.GetComponent<Animator>().runtimeAnimatorController = this.Aidmr;
                    }
                }
            }
            else if(enemyobj_ != null && enemyobj_.state==animationstate.sleep)
            {
                //播放睡眠动画
                if(enemyobj_ != null)
                {
                    if (enemyobj_.leftorright == 0)
                    {
                        enemyobj_.enemyobj.GetComponent<Animator>().runtimeAnimatorController = this.Aidz;
                    }
                    else
                    {
                        enemyobj_.enemyobj.GetComponent<Animator>().runtimeAnimatorController = this.Aidzr;
                    }
                }
            }
            else if (enemyobj_ != null && enemyobj_.state == animationstate.dite)
            {
                if (enemyobj_ != null)
                {
                    if (enemyobj_.leftorright == 0)
                    {
                        enemyobj_.enemyobj.GetComponent<Animator>().runtimeAnimatorController = this.Aidd;
                        StartCoroutine("bloodStains", enemyobj_);
                    }
                    else
                    {
                        enemyobj_.enemyobj.GetComponent<Animator>().runtimeAnimatorController = this.Aiddr;
                        StartCoroutine("bloodStains", enemyobj_);
                    }
                }

            }
        }

    }

    //敌人死亡留下的血迹
    IEnumerator bloodStains(enemyobj_node enemyobj_)
    {
        yield return new WaitForSeconds(3f);

        //enemyobj_.enemyobj.GetComponent<Animator>().runtimeAnimatorController = this.blood;
        if (enemyobj_ != null)
        {
            enemyobj_.enemyobj.GetComponent<Play2D>().WPoints = enemyobj_.enemyobj.position;
            enemyobj_.enemyobj.GetComponent<Play2D>().MoveRandom();
            enemyobj_.enemyobj.GetComponent<ParticleSystem>().Play();
            enemyobj_.enemyobj.GetComponent<Image>().sprite = image;
            DestroyImmediate(enemyobj_.enemyobj.GetComponent<Animator>());
            StartCoroutine("des",enemyobj_);

        }

    }

    IEnumerator des(enemyobj_node enemyobj_)
    {
        yield return new WaitForSeconds(5f);
        if (enemyobj_ != null)
        {
            for (int j = 0; j < enemyobj_lis.Count; ++j)
            {
                if (enemyobj_.enemyobj.name.Equals(enemyobj_lis[j].enemyobj.name))
                {
                    List<enemyobj_node> _Nodes = new List<enemyobj_node>();
                    for (int k = 0; k < enemyobj_lis.Count; ++k)
                    {
                        if (k != j)
                        {
                            _Nodes.Add(enemyobj_lis[k]);
                        }
                    }
                    enemyobj_lis.Clear();

                    for (int k = 0; k < _Nodes.Count; ++k)
                    {
                        enemyobj_lis.Add(_Nodes[k]);
                    }
                    j--;
                }
            }


            Destroy(enemyobj_.enemyobj.gameObject);
        }
            
    }
    void OnDrawGizmosSelected()
    {
        //for (int i = 0; i < end_Nodes.Count; i++)
        //{
        //    Gizmos.DrawSphere(end_Nodes[i].transformend.position, 0.1f);

        //}
        //for(int i = 0; i < this.patrol.Count; ++i)
        //{
        //    Gizmos.DrawSphere(this.patrol[i], 0.1f);
        //}

    }

    
}
