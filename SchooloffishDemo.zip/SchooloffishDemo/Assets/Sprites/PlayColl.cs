﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayColl : MonoBehaviour {

    // Use this for initialization
    public List<AIPlayer.enemyobj_node> transforms;//怪物集合
    public List<AIPlayer.player_node> player_Nodes;
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnCollisionStay(Collision collision)
    {
        print("stay");
        for(int i = 0; i < this.transforms.Count; ++i)
        {
            if (collision.collider.name.Equals(this.transforms[i].enemyobj.name))
            {
                this.transforms[i].lifevlue -= player_Nodes[0].hurt;
                
            }
        }
    }
}
