﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


//example. moving between some points at random
[RequireComponent(typeof(PolyNavAgent))]
public class Play2D : MonoBehaviour
{

    public Vector2 WPoints;
    public float delayBetweenPoints = 0f;


    public List<Vector2> vector2s;

    private PolyNavAgent _agent;
    private PolyNavAgent agent
    {
        get { return _agent != null ? _agent : _agent = GetComponent<PolyNavAgent>(); }
    }

   

    void Start()
    {
       
    }

    public void MoveRandom()
    {
        StartCoroutine(WaitAndMove());
    }

    IEnumerator WaitAndMove()
    {
        yield return new WaitForSeconds(delayBetweenPoints);
        agent.SetDestination(WPoints);
    }

    public void MoveRandom1()
    {
        StartCoroutine(WaitAndMove1());
    }

    IEnumerator WaitAndMove1()
    {
        yield return new WaitForSeconds(delayBetweenPoints);
        agent.SetDestination(vector2s[(int)(Random.value*(vector2s.Count))]);
    }

    public void Onrun()
    {
        agent.OnDestinationReached += MoveRandom1;
        agent.OnDestinationInvalid += MoveRandom1;
    }

    public void Onstop()
    {
        agent.OnDestinationReached -= MoveRandom1;
        agent.OnDestinationInvalid -= MoveRandom1;
    }

    void OnDrawGizmosSelected()
    {
       Gizmos.DrawSphere(WPoints, 0.05f);
    }
}
